"""Initializating script for the python package
"""
from .fetcher import *
from .streamer import *
